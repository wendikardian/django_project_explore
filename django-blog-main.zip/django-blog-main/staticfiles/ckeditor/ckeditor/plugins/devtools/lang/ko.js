﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","ko",{title:"구성 요소 정보",dialogName:"다이얼로그 윈도우 이름",tabName:"탭 이름",elementId:"요소 ID",elementType:"요소 형식"});